# Connect Gmail

## What You Walk Away With

Claude can read your email, search your inbox, and draft replies — all from the terminal. No browser, no clicking, no tab switching.

---

## What This Connection Lets Claude Do

- **Triage your inbox** — "Show me all unread emails from the last 24 hours. Separate brand deals from noise."
- **Search for specific threads** — "Find every email from Sarah about the sponsorship deal."
- **Draft replies** — "Draft a reply to that Stripe email saying I'll review the invoice tomorrow."
- **Read full threads** — "What did Trevor say in that client thread from last week? Summarize it."

This is the foundation for the `/manage-email` and `/morning` skills. Without Gmail connected, those skills can't run.

---

## How to Install It

Open Claude Code and say:

```
Install the Gmail MCP server. Here's the config — add it to my MCP settings.
```

Then paste the contents of the `config.json` file included with this lesson.

Claude will add it to your `.mcp.json` file. When it asks you to authenticate, follow the Google OAuth flow in your browser — sign into the Gmail account you want Claude to access, and approve the permissions.

That's it. Restart Claude Code and the connection is live.

---

## How to Verify It Works

After restarting Claude Code, ask:

```
Search my Gmail for emails from the last 7 days. Show me the 5 most recent.
```

If Claude returns your actual emails with subjects, senders, and dates — you're good. If it errors out, check the Stuck section below.

---

## Key Takeaway

Gmail MCP gives Claude read access to your inbox. It can search, read, and draft — but it can't send, star, or mark-as-read on its own. For those actions, you'll pair it with an n8n workflow (covered in the `/manage-email` skill lesson).

---

## Stuck?

**"OAuth flow failed" or "Authentication error"**
Make sure you're signing into the correct Google account. If you have multiple accounts, use an incognito window to force a clean login.

**"No results found" when searching**
The MCP server needs a moment after first setup. Restart Claude Code, wait 10 seconds, and try again.

**"Permission denied"**
You might have skipped the consent screen. Re-run the OAuth flow and make sure you click "Allow" on every permission.
