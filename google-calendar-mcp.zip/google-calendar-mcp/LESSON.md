# Connect Google Calendar

## What You Walk Away With

Claude can see your schedule, create events, find free time, and manage your calendar — without you ever opening Google Calendar.

---

## What This Connection Lets Claude Do

- **Check your schedule** — "What do I have on my calendar this week?"
- **Book new events** — "Schedule a call with the client for Tuesday at 2pm. Add a Zoom link."
- **Find open slots** — "When am I free for a 30-minute call this Thursday?"
- **Move or cancel meetings** — "Push my 3pm tomorrow to Friday same time."

If you run a coaching business, agency, or any service where you're booking calls — this saves you from living inside Google Calendar. Ask Claude "when am I free this week?" and get an instant answer while you're working on something else.

---

## How to Install It

Open Claude Code and say:

```
Install the Google Calendar MCP server. Here's the config — add it to my MCP settings.
```

Then paste the contents of the `config.json` file included with this lesson.

Claude will add it to your `.mcp.json` file. When it asks you to authenticate, follow the Google OAuth flow in your browser — sign into the Google account with the calendar you want Claude to manage, and approve the permissions.

Restart Claude Code and the connection is live.

---

## How to Verify It Works

After restarting Claude Code, ask:

```
What's on my calendar for the next 3 days?
```

If Claude returns your actual events with times, titles, and attendees — you're connected. If it shows nothing and you know you have events, check the Stuck section below.

---

## Key Takeaway

Google Calendar MCP gives Claude full read and write access to your calendar. It can list events, create new ones, find free time, and update existing meetings. Pair it with the `/morning` skill so your daily briefing includes today's schedule automatically.

---

## Stuck?

**"OAuth flow failed" or "Authentication error"**
Same fix as Gmail — use an incognito window if you have multiple Google accounts. Make sure you approve calendar-specific permissions.

**"No events found" but I have events**
Make sure you signed into the Google account that actually has your calendar. If you use a workspace account (yourname@company.com), that's the one you need to authenticate with.

**"Can't create events"**
The OAuth consent screen needs both read and write calendar permissions. If you only approved read access, re-run the auth flow and approve everything.

**Using the same Google account as Gmail?**
That's fine. The OAuth credentials can be shared. You'll authenticate once and both servers use the same Google account.
