# Connect Notion

## What You Walk Away With

Claude can search, read, and navigate your Notion workspace. Your SOPs, meeting notes, project docs, databases — Claude can find and read anything in Notion without you opening a browser tab.

---

## What This Connection Lets Claude Do

- **Search your workspace** — "Find my client onboarding SOP in Notion."
- **Read pages** — "Pull up the meeting notes from last Tuesday's call with the client."
- **Browse databases** — "Show me everything in my Content Calendar database."
- **Cross-reference docs** — "Compare what's in my Notion project plan with what's in my Airtable task board."

If you keep your business docs in Notion — SOPs, client briefs, project plans, meeting notes — this connection turns Claude into a search engine for your own knowledge base. A real estate agent can say "find my listing presentation template" and Claude pulls it up instantly. A coach can say "what was the action plan from my last client session?" and get the answer without hunting through pages.

---

## How to Install It

**Step 1: Create a Notion integration**

Go to [notion.so/my-integrations](https://notion.so/my-integrations) and click "Create new integration."

- **Name:** Claude Code (or whatever you want)
- **Associated workspace:** Select your workspace
- Copy the **Internal Integration Secret** (starts with `ntn_`)

**Step 2: Connect pages to your integration (critical step)**

This is the part people miss. Creating the integration isn't enough — you have to explicitly give it access to each page or database you want Claude to see.

In Notion:
1. Open any page or database you want Claude to access
2. Click the `...` menu in the top right
3. Click **Connections**
4. Search for "Claude Code" (or whatever you named your integration)
5. Click to add it

Repeat for every top-level page you want Claude to see. Child pages inherit access from their parent, so you don't need to do it for every sub-page.

**Step 3: Give it to Claude**

Open Claude Code and say:

```
Install the Notion MCP server. Here's the config — add it to my MCP settings.
```

Then paste the contents of the `config.json` file included with this lesson. Replace `YOUR_NOTION_INTEGRATION_SECRET` with the token you copied in Step 1.

Restart Claude Code and the connection is live.

---

## How to Verify It Works

After restarting Claude Code, ask:

```
Search my Notion workspace for any page with "SOP" in the title.
```

If Claude returns matching pages from your workspace — you're connected. If it returns nothing but you know those pages exist, you probably skipped Step 2 (connecting pages to the integration).

---

## Key Takeaway

Notion MCP gives Claude read access to your workspace. The biggest gotcha is Step 2 — you have to manually connect your integration to each top-level page. Without that step, Claude has a valid key but can't see anything. Once connected, Claude becomes a search engine for your entire business knowledge base.

---

## Stuck?

**"No results" but I know the page exists**
90% of the time this means you didn't connect the page to your integration (Step 2 above). Open the page in Notion, click `...` > Connections, and add your integration.

**"Invalid token" or "Unauthorized"**
Make sure you copied the full integration secret (starts with `ntn_`). Go back to notion.so/my-integrations and verify the integration is active.

**"Can't find my database"**
Notion databases need to be connected to the integration just like pages. Open the database, click `...` > Connections, and add your integration.

**"I connected a parent page but child pages don't show up"**
Child pages should inherit access automatically. If they don't, try disconnecting and reconnecting the integration on the parent page. In rare cases, you may need to connect sub-pages individually.
