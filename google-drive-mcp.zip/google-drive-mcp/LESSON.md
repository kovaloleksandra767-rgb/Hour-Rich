# MCP Install: Google Drive

## What You'll Walk Away With

Claude Code connected to your Google Drive. You'll be able to search for files, read documents, and find anything in your Drive — all without leaving the terminal.

---

## What This Connection Lets Claude Do

- **Search your entire Drive** — "Find the client onboarding doc I made last month." Claude searches by name, content, and file type.
- **Read document contents** — "What does my SOPs folder say about handling refunds?" Claude opens and reads the doc.
- **Browse folders** — "List everything in my 'Ad Creatives' folder." Claude shows you what's in there.
- **Cross-reference files** — "Compare what's in my proposal template vs the one I sent to the last client." Claude reads both and compares.

**Real examples:**
- A gym owner says "Find the waiver form" and Claude pulls it from Drive in 2 seconds instead of scrolling through folders
- A coach asks "What did I write in my Q1 business plan?" and Claude reads the Google Doc and summarizes it
- A real estate agent says "Find all the listing photos for 123 Oak Street" and Claude searches their shared Drive
- An ecommerce store owner asks Claude to read their supplier agreement and flag the return policy terms

---

## How to Install It

Open Claude Code and say:

```
Install the Google Drive MCP server. Here's my config:
```

Then paste the contents of `config.json` (attached to this lesson) with your Google OAuth credentials filled in.

Claude will install and register the server automatically.

**To get your credentials:**
1. Go to [console.cloud.google.com](https://console.cloud.google.com)
2. Create a new project (or use an existing one)
3. Go to **APIs & Services** → **Library** → search "Google Drive API" → **Enable** it
4. Go to **APIs & Services** → **Credentials** → **Create Credentials** → **OAuth 2.0 Client ID**
5. Set application type to **Web application**
6. Under "Authorized redirect URIs," add: `http://localhost:3000/callback`
7. Copy the **Client ID** and **Client Secret**
8. On first run, it will open your browser for OAuth consent — authorize it and you're set

---

## How to Verify It Works

After installing, ask Claude:

```
Search my Google Drive for recent files.
```

If Claude returns a list of your files, you're connected. If it errors, check the Stuck? section below.

---

## Key Takeaway

Google Drive MCP lets Claude search and read your files like a second brain. If your business docs, SOPs, client files, or templates live in Google Drive, Claude can find and reference them instantly. No more digging through folders.

---

## Stuck?

**"OAuth consent screen error"**
Make sure you've configured the OAuth consent screen in Google Cloud Console. Go to APIs & Services → OAuth consent screen → set it to "External" (or "Internal" if you have Google Workspace) and add your email as a test user.

**"Redirect URI mismatch"**
The redirect URI in your Google Cloud project must match exactly: `http://localhost:3000/callback`. No trailing slash, no https.

**"Access denied" or "insufficient permissions"**
When the browser opens for OAuth, make sure you check the box that says "See, edit, create, and delete all of your Google Drive files." If you skipped it, you'll need to reauthorize.

**"Token expired"**
Google OAuth tokens expire. If it stops working after a while, delete the stored token file and reauthorize by restarting the MCP server.

---

## Download

**One file included with this lesson:**

1. **`config.json`** — The MCP server configuration
   Add to your project's `.mcp.json` or `~/.claude.json` (global)
