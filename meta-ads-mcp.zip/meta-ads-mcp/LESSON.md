# Connect Meta Ads

## What You Walk Away With

Claude can manage your Facebook and Instagram ad campaigns — check performance, create campaigns, adjust budgets, and pause underperformers. All from the terminal without logging into Ads Manager.

---

## What This Connection Lets Claude Do

- **Check ad performance** — "How are my Meta ads doing this week? Show me spend, ROAS, and cost per lead for each campaign."
- **Create campaigns** — "Launch a new lead gen campaign targeting gym owners in Austin, $50/day budget, using this ad creative."
- **Adjust budgets** — "My top campaign is crushing it. Double the daily budget from $50 to $100."
- **Pause or enable ads** — "Pause every ad set with a cost per lead above $15."

If you run ads for your own business or for clients, this is a game changer. A gym owner can ask "which ad is getting me the cheapest leads?" and get an instant answer. An agency owner can check all their client campaigns in one conversation instead of logging into 5 different ad accounts.

---

## How to Install It

This one has a few more steps than the others, but it's still a one-time setup.

**Step 1: Get your Meta credentials**

Go to [developers.facebook.com/apps](https://developers.facebook.com/apps). Either create a new app or select your existing one.

You need 4 things:
1. **App ID** — visible on your app's dashboard
2. **App Secret** — under App Settings > Basic
3. **Access Token** — use the Access Token Tool in your app dashboard, or create a System User token in Business Manager for a longer-lived token
4. **Ad Account ID** — format is `act_XXXXXXXXX` (include the `act_` prefix). Find it in Ads Manager under Account Settings.

Your token needs these permissions:
- `ads_management`
- `ads_read`
- `pages_manage_ads`
- `pages_read_engagement`

**Step 2: Give it to Claude**

Open Claude Code and say:

```
Install the Meta Ads MCP server. Here's the config — add it to my MCP settings.
```

Then paste the contents of the `config.json` file included with this lesson. Replace all four `YOUR_*` placeholders with your actual credentials.

Restart Claude Code and the connection is live.

---

## How to Verify It Works

After restarting Claude Code, ask:

```
Show me a summary of my Meta ad account — total spend and results for the last 7 days.
```

If Claude returns your actual ad spend and metrics — you're connected.

---

## Key Takeaway

Meta Ads MCP gives Claude full control over your ad account. Read performance data, create campaigns, adjust budgets, manage audiences. This powers the `/launch-ads`, `/ad-brief`, and `/script-ads` skills. If you run an agency, you can connect multiple ad accounts (one per client) and manage them all through Claude.

---

## Stuck?

**"Invalid access token"**
Meta tokens expire. If you used a short-lived token from the Graph API Explorer, it's only good for about 1 hour. For production use, generate a System User token in Business Manager — those last much longer.

**"Permission denied" or "Insufficient permissions"**
Your token needs `ads_management` and `ads_read` at minimum. Go to your app's permissions page and make sure those are approved.

**"Ad account not found"**
Make sure your Ad Account ID includes the `act_` prefix (e.g., `act_123456789`). Just the numbers alone won't work.

**"App not connected to ad account"**
In Business Manager, go to Business Settings > Ad Accounts > select your account > Connected Assets, and make sure your app is connected.
